package x3.player.mru.surfif.types;

public enum SurfEndpointType {
    ENDPOINT_TYPE_P2P,
    ENDPOINT_TYPE_FE
}
