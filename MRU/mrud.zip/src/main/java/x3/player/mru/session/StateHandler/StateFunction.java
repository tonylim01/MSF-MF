package x3.player.mru.session.StateHandler;

import x3.player.mru.session.SessionInfo;

public interface StateFunction {
    void run(SessionInfo sessionInfo, Object arg);
}
