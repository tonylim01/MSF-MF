package x3.player.mru.surfif.messages;

public class SurfMsgEvent {
    private String type;
    private boolean enabled;

    public void setType(String type) {
        this.type = type;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
