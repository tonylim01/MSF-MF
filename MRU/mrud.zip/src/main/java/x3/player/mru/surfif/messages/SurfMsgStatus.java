package x3.player.mru.surfif.messages;

public class SurfMsgStatus {
    private String type;
    private int period;

    public void setType(String type) {
        this.type = type;
    }

    public void setPeriod(int period) {
        this.period = period;
    }
}
