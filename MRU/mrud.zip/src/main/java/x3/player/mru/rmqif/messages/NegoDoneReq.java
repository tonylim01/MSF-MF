package x3.player.mru.rmqif.messages;

public class NegoDoneReq {
    private String sdp;

    public String getSdp() {
        return sdp;
    }

    public void setSdp(String sdp) {
        this.sdp = sdp;
    }
}
