package x3.player.mru.rmqif.messages;

public class CommandEndRes {
}
