package x3.player.mru.surfif.module;

public class SurfChannelInfo {

    private int id;
    private boolean isBusy;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isBusy() {
        return isBusy;
    }

    public void setBusy(boolean busy) {
        isBusy = busy;
    }
}
